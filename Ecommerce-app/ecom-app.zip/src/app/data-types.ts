export interface signup{
    name:string
    email:string
    password:string
}